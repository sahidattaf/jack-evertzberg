# Jack Evertzberg Development

> **Flagship mixed‑use waterfront destination in Curaçao blending ultra‑luxury living, smart‑city tech, and regenerative design.**

## Repo Overview
| Folder | Purpose |
|--------|---------|
| **docs/** | Master‑plan PDFs, ESG reports, permits |
| **financials/** | CapEx, P&L, sensitivity models |
| **models/** | BIM exports, smart contracts |
| **automation/** | Python scripts for CapEx curves & data pulls |
| **marketing/** | Brand assets, VR demos, Next.js microsite |
| **.github/workflows/** | CI/CD (lint, tests, deploy) |

## Quick Start
```bash
git clone https://github.com/YOUR-ORG/jack-evertzberg.git
cd jack-evertzberg
python -m venv .venv && source .venv/bin/activate
pip install -r automation/requirements.txt
```

## Maintainers
- **Sahid Attaf** – Project Lead / Vision
- **Dev Director** – Infrastructure & BIM
- **CFO** – Financial Models & CapEx scripts

*Generated via ChatGPT – May 2025.*
